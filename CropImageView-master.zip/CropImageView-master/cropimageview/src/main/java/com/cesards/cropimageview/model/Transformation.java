package com.cesards.cropimageview.model;

import android.graphics.Matrix;

public interface Transformation {
  Matrix getMatrix();
}
