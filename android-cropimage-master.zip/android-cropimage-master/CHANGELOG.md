# Change Log

All notable changes to this project will be documented in this file. This project adheres to
[Semantic Versioning](http://semver.org/).


## 1.1.1 - 2015-06-03

* Add Indonesian translation.


## 1.1.0 - 2015-03-07

### Added

* It is now possible to change the default color of the crop outline for both standards and face
  detection crops. [bf52bd38](https://github.com/lvillani/android-cropimage/commit/bf52bd3866be669d071b02e024073ade0d53e261)
