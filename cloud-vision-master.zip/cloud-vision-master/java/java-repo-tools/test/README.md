# Cloud Platform Java Repository Tools Test

This is a test application for checking that the root [`pom.xml`](../pom.xml)
and [`google-checks.xml`](../google-checks.xml) are working as expected.

