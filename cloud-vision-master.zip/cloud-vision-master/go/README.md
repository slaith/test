# Cloud Vision API Go samples

This directory contains [Cloud Vision API](https://cloud.google.com/vision/) Go samples and utilities.

## Samples

### Label Detection

See the [label detection](https://cloud.google.com/vision/docs/label-tutorial) tutorial in the docs.

[Go Code](label)

